package com.abdu.goldscalper;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import org.json.JSONObject;
import java.net.*;
import java.io.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private final int BG=Color.rgb(12,12,12), PANEL=Color.rgb(29,29,29), GOLD=Color.rgb(222,181,75);
    private EditText serverInput, tokenInput, riskInput;
    private TextView connection, balance, equity, pnl, botState, message;
    private ExecutorService executor=Executors.newSingleThreadExecutor();
    private String baseUrl="", token="";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        ScrollView scroll=new ScrollView(this); scroll.setBackgroundColor(BG);
        LinearLayout page=new LinearLayout(this); page.setOrientation(1); page.setPadding(22,24,22,24);
        scroll.addView(page); setContentView(scroll);

        TextView brand=text("ABDU GOLD SCALPER",26,GOLD,true); page.addView(brand);
        TextView sub=text("XAUUSD  •  MT5 CONTROL CENTER",12,Color.LTGRAY,false); page.addView(sub);
        connection=text("● غير متصل بالسيرفر",14,0xffffb74d,true); addGap(page,18); page.addView(connection);

        LinearLayout stats=new LinearLayout(this); stats.setOrientation(0);
        balance=statCard(stats,"BALANCE","—"); equity=statCard(stats,"EQUITY","—"); page.addView(stats);
        LinearLayout stats2=new LinearLayout(this); stats2.setOrientation(0);
        pnl=statCard(stats2,"TODAY P/L","—"); botState=statCard(stats2,"BOT STATUS","غير معروف"); page.addView(stats2);

        addGap(page,18); page.addView(text("التحكم في البوت",18,Color.WHITE,true));
        Button start=button("تشغيل البوت"); page.addView(start);
        Button stop=button("إيقاف البوت"); page.addView(stop);
        start.setOnClickListener(v->postCommand("/bot/start"));
        stop.setOnClickListener(v->postCommand("/bot/stop"));

        addGap(page,16); page.addView(text("إعدادات الاتصال",18,Color.WHITE,true));
        serverInput=new EditText(this); serverInput.setSingleLine(true);
        serverInput.setHint("HTTPS API URL مثال: https://your-vps-domain.com");
        styleInput(serverInput); page.addView(serverInput);
        tokenInput=new EditText(this); tokenInput.setSingleLine(true);
        tokenInput.setHint("API Token"); tokenInput.setInputType( android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        styleInput(tokenInput); page.addView(tokenInput);
        riskInput=new EditText(this); riskInput.setSingleLine(true); riskInput.setText("0.5");
        riskInput.setHint("المخاطرة % (مثلاً 0.5)"); styleInput(riskInput); page.addView(riskInput);

        Button save=button("حفظ الإعدادات والاتصال"); page.addView(save);
        Button refresh=button("تحديث حالة الحساب"); page.addView(refresh);
        Button risk=button("تحديث نسبة المخاطرة"); page.addView(risk);
        message=text("تنبيه: الواجهة لا تتصل مباشرة ببرنامج MT5. يلزم تثبيت API Bridge آمن على VPS.",12,0xffbbbbbb,false);
        addGap(page,12); page.addView(message);

        save.setOnClickListener(v->{baseUrl=serverInput.getText().toString().trim(); token=tokenInput.getText().toString().trim();
            if(!baseUrl.startsWith("https://")) { setMessage("استخدم عنوان HTTPS آمن للسيرفر."); return; }
            refreshStatus();
        });
        refresh.setOnClickListener(v->{baseUrl=serverInput.getText().toString().trim(); token=tokenInput.getText().toString().trim(); refreshStatus();});
        risk.setOnClickListener(v->{
            double r; try { r=Double.parseDouble(riskInput.getText().toString()); } catch(Exception e){setMessage("أدخل نسبة مخاطرة صحيحة."); return;}
            if(r<=0 || r>0.5){setMessage("في هذه النسخة الحد الأقصى المسموح 0.5%."); return;}
            postJson("/settings", "{\"risk_percent\":"+r+"}");
        });
    }

    private TextView statCard(LinearLayout row,String title,String value) {
        LinearLayout card=new LinearLayout(this); card.setOrientation(1); card.setPadding(14,14,14,14);
        card.setBackgroundColor(PANEL); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1); lp.setMargins(0,8,8,8); row.addView(card,lp);
        TextView t=text(title,10,0xffaaaaaa,true), v=text(value,19,GOLD,true); card.addView(t); card.addView(v);
        return v;
    }
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,1);t.setPadding(0,5,0,5);return t;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.BLACK);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(GOLD));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,7,0,7);b.setLayoutParams(p);return b;}
    private void styleInput(EditText e){e.setTextColor(Color.WHITE);e.setHintTextColor(0xff888888);e.setPadding(14,10,14,10);e.setBackgroundColor(PANEL);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,6,0,6);e.setLayoutParams(p);}
    private void addGap(LinearLayout l,int h){View v=new View(this);l.addView(v,new LinearLayout.LayoutParams(1,h));}
    private void setMessage(String s){runOnUiThread(()->message.setText(s));}

    private void refreshStatus(){request("GET","/status",null);}
    private void postCommand(String path){request("POST",path,"{}");}
    private void postJson(String path,String body){request("POST",path,body);}

    private void request(String method,String path,String body){
        if(baseUrl.isEmpty()) baseUrl=serverInput.getText().toString().trim();
        if(token.isEmpty()) token=tokenInput.getText().toString().trim();
        if(!baseUrl.startsWith("https://") || token.isEmpty()){setMessage("أدخل رابط HTTPS و API Token أولاً.");return;}
        executor.execute(()->{
            HttpURLConnection c=null;
            try{
                URL u=new URL(baseUrl.replaceAll("/+$","")+path);
                c=(HttpURLConnection)u.openConnection(); c.setRequestMethod(method); c.setConnectTimeout(8000); c.setReadTimeout(8000);
                c.setRequestProperty("Authorization","Bearer "+token); c.setRequestProperty("Content-Type","application/json");
                if(body!=null){c.setDoOutput(true);try(OutputStream os=c.getOutputStream()){os.write(body.getBytes("UTF-8"));}}
                int code=c.getResponseCode(); InputStream is=(code>=200&&code<300)?c.getInputStream():c.getErrorStream();
                ByteArrayOutputStream out=new ByteArrayOutputStream(); byte[] buf=new byte[1024]; int n; while((n=is.read(buf))>0)out.write(buf,0,n);
                JSONObject j=new JSONObject(out.toString("UTF-8"));
                if(code>=200&&code<300){
                    runOnUiThread(()->{
                        connection.setText("● متصل بالسيرفر"); connection.setTextColor(0xff55cc88);
                        if(j.has("balance")) balance.setText(j.optString("balance"));
                        if(j.has("equity")) equity.setText(j.optString("equity"));
                        if(j.has("today_pnl")) pnl.setText(j.optString("today_pnl"));
                        if(j.has("bot_status")) botState.setText(j.optString("bot_status"));
                        setMessage(j.optString("message","تم تنفيذ الطلب."));
                    });
                }else setMessage("رفض السيرفر الطلب (HTTP "+code+").");
            }catch(Exception e){runOnUiThread(()->{connection.setText("● غير متصل");connection.setTextColor(0xffffb74d);setMessage("تعذر الاتصال: "+e.getMessage());});}
            finally{if(c!=null)c.disconnect();}
        });
    }
    @Override protected void onDestroy(){super.onDestroy();executor.shutdown();}
}
