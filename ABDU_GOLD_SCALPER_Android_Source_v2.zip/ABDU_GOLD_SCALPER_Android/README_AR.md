# ABDU GOLD SCALPER — Android starter

هذه نسخة مشروع Android أولية بواجهة سوداء وذهبية. ليست APK جاهزة، ولا تتصل مباشرة ببرنامج MT5.

## ما الذي يعمل الآن؟
- واجهة عربية/إنجليزية أولية.
- حقول عنوان خادم HTTPS و API Token.
- أزرار تشغيل وإيقاف البوت.
- طلب حالة الحساب وتحديث المخاطرة عبر HTTP API.
- حد المخاطرة في الواجهة 0.5%.

## المطلوب حتى يصبح التحكم حقيقياً
يجب بناء API Bridge على VPS بجانب MT5، مع Expert Advisor يتواصل مع هذا الجسر. التطبيق يتوقع هذه المسارات:

- `GET /status` يرجع JSON مثل:
  `{"balance":"1000.00","equity":"998.50","today_pnl":"-1.50","bot_status":"RUNNING"}`
- `POST /bot/start` يرجع `{"message":"Start command accepted"}`
- `POST /bot/stop` يرجع `{"message":"Stop command accepted"}`
- `POST /settings` يستقبل `{"risk_percent":0.5}`

كل الطلبات تتطلب:
`Authorization: Bearer YOUR_LONG_RANDOM_TOKEN`

**لا تفتح API على الإنترنت بدون HTTPS ومصادقة قوية وتقييد الوصول.** لا تضع كلمة مرور حساب MT5 داخل التطبيق. ابدأ بحساب تجريبي، وأضف تأكيداً إضافياً قبل أوامر التشغيل والإيقاف في النسخة الإنتاجية.

## بناء APK
1. افتح المشروع في Android Studio على كمبيوتر.
2. ثبّت Android SDK 35 و Gradle حسب طلب Android Studio.
3. انتظر Gradle Sync.
4. اختر Build > Build Bundle(s) / APK(s) > Build APK(s).
5. ستجد APK عادة في `app/build/outputs/apk/debug/`.

## ملاحظة
لا يمكن إصدار APK متصل بحساب حقيقي قبل تنفيذ API Bridge واختباره مع EA على VPS. هذا المشروع هو نقطة بداية قابلة للبناء والتطوير.
